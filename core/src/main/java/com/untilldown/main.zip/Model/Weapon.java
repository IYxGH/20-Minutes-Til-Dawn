package com.untilldown.Model;

public class Weapon {
}
