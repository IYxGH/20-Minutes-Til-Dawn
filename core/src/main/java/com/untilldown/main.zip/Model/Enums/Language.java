package com.untilldown.Model.Enums;

public enum Language {
    ENGLISH,
    SPANISH,
}
