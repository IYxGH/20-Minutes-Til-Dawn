package com.untilldown.View.MenusViewInMain;


import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.untilldown.Controller.MenuControllersInMain.TalentController;

public class TalentView implements Screen {
    private final TalentController controller;
    private Stage stage;
    private Skin skin;

    public TalentView(TalentController controller, Skin skin) {
        this.controller = controller;
        this.skin = skin;

        //TODO
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
