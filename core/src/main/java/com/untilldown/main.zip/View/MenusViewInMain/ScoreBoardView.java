package com.untilldown.View.MenusViewInMain;


import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.untilldown.Controller.MenuControllersInMain.ScoreBoardController;

public class ScoreBoardView implements Screen {
    private final ScoreBoardController controller;
    private final Skin skin;
    private Stage stage;

    public ScoreBoardView(ScoreBoardController controller, Skin skin) {
        this.controller = controller;
        this.skin = skin;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
