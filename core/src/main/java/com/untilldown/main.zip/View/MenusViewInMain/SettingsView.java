package com.untilldown.View.MenusViewInMain;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.untilldown.Controller.MenuControllersInMain.SettingsController;

public class SettingsView implements Screen {
    private final SettingsController controller;
    private Skin skin;
    private Stage stage;

    public SettingsView(SettingsController controller, Skin skin) {
        this.controller = controller;
        this.skin = skin;

        //TODO
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
