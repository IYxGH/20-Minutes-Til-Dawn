package com.untilldown.Controller.ModelControllers;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.untilldown.Model.Player;
import com.untilldown.Model.Weapon;

public class WeaponController {
    private Weapon weapon;

    public void initWeapons(Stage stage, Player player) {

    }

    public void update(float delta) {

    }

}
