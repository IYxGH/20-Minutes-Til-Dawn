package com.untilldown.Controller.MenuControllersInMain;

public class TalentController {
}
